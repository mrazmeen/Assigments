import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

const baseUrl = 'http://localhost:2000/AdminSignup/SaveAdminDetailes';


@Injectable({
  providedIn: 'root'
})
export class TestserviceService {

  constructor(private http: HttpClient) { }

  create(data) {
    return this.http.post(baseUrl, data);
  }
  


}
